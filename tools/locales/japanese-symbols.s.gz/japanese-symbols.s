.syntax unified
.global gBagMenuHMIcon_Gfx
.type gBagMenuHMIcon_Gfx, %object
.equ gBagMenuHMIcon_Gfx, 140376476
.size gBagMenuHMIcon_Gfx, 128
.global gBerryBlenderStart_Gfx
.type gBerryBlenderStart_Gfx, %object
.equ gBerryBlenderStart_Gfx, 137422260
.size gBerryBlenderStart_Gfx, 1024
.global gBerryCheckCircle_Gfx
.type gBerryCheckCircle_Gfx, %object
.equ gBerryCheckCircle_Gfx, 148489460
.size gBerryCheckCircle_Gfx, 347
.global gBerryCrush_Crusher_Gfx
.type gBerryCrush_Crusher_Gfx, %object
.equ gBerryCrush_Crusher_Gfx, 137126148
.size gBerryCrush_Crusher_Gfx, 2830
.global gContestApplauseGfx
.type gContestApplauseGfx, %object
.equ gContestApplauseGfx, 148433580
.size gContestApplauseGfx, 299
.global gContestInterfaceGfx
.type gContestInterfaceGfx, %object
.equ gContestInterfaceGfx, 146897592
.size gContestInterfaceGfx, 2965
.global gContestResultsTitle_Beauty_Tilemap
.type gContestResultsTitle_Beauty_Tilemap, %object
.equ gContestResultsTitle_Beauty_Tilemap, 139891688
.size gContestResultsTitle_Beauty_Tilemap, 20
.global gContestResultsTitle_Cool_Tilemap
.type gContestResultsTitle_Cool_Tilemap, %object
.equ gContestResultsTitle_Cool_Tilemap, 139891668
.size gContestResultsTitle_Cool_Tilemap, 20
.global gContestResultsTitle_Cute_Tilemap
.type gContestResultsTitle_Cute_Tilemap, %object
.equ gContestResultsTitle_Cute_Tilemap, 139891708
.size gContestResultsTitle_Cute_Tilemap, 20
.global gContestResultsTitle_Hyper_Tilemap
.type gContestResultsTitle_Hyper_Tilemap, %object
.equ gContestResultsTitle_Hyper_Tilemap, 139891572
.size gContestResultsTitle_Hyper_Tilemap, 32
.global gContestResultsTitle_Link_Tilemap
.type gContestResultsTitle_Link_Tilemap, %object
.equ gContestResultsTitle_Link_Tilemap, 139891636
.size gContestResultsTitle_Link_Tilemap, 32
.global gContestResultsTitle_Master_Tilemap
.type gContestResultsTitle_Master_Tilemap, %object
.equ gContestResultsTitle_Master_Tilemap, 139891604
.size gContestResultsTitle_Master_Tilemap, 32
.global gContestResultsTitle_Normal_Tilemap
.type gContestResultsTitle_Normal_Tilemap, %object
.equ gContestResultsTitle_Normal_Tilemap, 139891508
.size gContestResultsTitle_Normal_Tilemap, 32
.global gContestResultsTitle_Smart_Tilemap
.type gContestResultsTitle_Smart_Tilemap, %object
.equ gContestResultsTitle_Smart_Tilemap, 139891728
.size gContestResultsTitle_Smart_Tilemap, 20
.global gContestResultsTitle_Super_Tilemap
.type gContestResultsTitle_Super_Tilemap, %object
.equ gContestResultsTitle_Super_Tilemap, 139891540
.size gContestResultsTitle_Super_Tilemap, 32
.global gContestResultsTitle_Tilemap
.type gContestResultsTitle_Tilemap, %object
.equ gContestResultsTitle_Tilemap, 139891768
.size gContestResultsTitle_Tilemap, 20
.global gContestResultsTitle_Tough_Tilemap
.type gContestResultsTitle_Tough_Tilemap, %object
.equ gContestResultsTitle_Tough_Tilemap, 139891748
.size gContestResultsTitle_Tough_Tilemap, 20
.global gContestResults_Gfx
.type gContestResults_Gfx, %object
.equ gContestResults_Gfx, 146904780
.size gContestResults_Gfx, 2151
.global gDomeTourneyTree_Gfx
.type gDomeTourneyTree_Gfx, %object
.equ gDomeTourneyTree_Gfx, 148385716
.size gDomeTourneyTree_Gfx, 1515
.global gEasyChatButtonWindow_Gfx
.type gEasyChatButtonWindow_Gfx, %object
.equ gEasyChatButtonWindow_Gfx, 139934472
.size gEasyChatButtonWindow_Gfx, 520
.global gEasyChatGroup_Move1
.type gEasyChatGroup_Move1, %object
.equ gEasyChatGroup_Move1, 139953692
.size gEasyChatGroup_Move1, 308
.global gEasyChatGroup_Move2
.type gEasyChatGroup_Move2, %object
.equ gEasyChatGroup_Move2, 139954000
.size gEasyChatGroup_Move2, 400
.global gEasyChatGroup_Pokemon
.type gEasyChatGroup_Pokemon, %object
.equ gEasyChatGroup_Pokemon, 139937156
.size gEasyChatGroup_Pokemon, 404
.global gEasyChatGroup_Pokemon2
.type gEasyChatGroup_Pokemon2, %object
.equ gEasyChatGroup_Pokemon2, 139954972
.size gEasyChatGroup_Pokemon2, 502
.global gEasyChatMode_Gfx
.type gEasyChatMode_Gfx, %object
.equ gEasyChatMode_Gfx, 139933684
.size gEasyChatMode_Gfx, 785
.global gFontNormalJapaneseGlyphs
.type gFontNormalJapaneseGlyphs, %object
.equ gFontNormalJapaneseGlyphs, 136974100
.size gFontNormalJapaneseGlyphs, 16384
.global gFontShortJapaneseGlyphs
.type gFontShortJapaneseGlyphs, %object
.equ gFontShortJapaneseGlyphs, 136990484
.size gFontShortJapaneseGlyphs, 32768
.global gFrontierPassBg_Gfx
.type gFrontierPassBg_Gfx, %object
.equ gFrontierPassBg_Gfx, 139749796
.size gFrontierPassBg_Gfx, 6083
.global gFrontierPassBg_Tilemap
.type gFrontierPassBg_Tilemap, %object
.equ gFrontierPassBg_Tilemap, 139761168
.size gFrontierPassBg_Tilemap, 743
.global gFrontierPassMapAndCard_Gfx
.type gFrontierPassMapAndCard_Gfx, %object
.equ gFrontierPassMapAndCard_Gfx, 139763232
.size gFrontierPassMapAndCard_Gfx, 4092
.global gFrontierPassMedals_Gfx
.type gFrontierPassMedals_Gfx, %object
.equ gFrontierPassMedals_Gfx, 139760112
.size gFrontierPassMedals_Gfx, 610
.global gHealthboxDoublesOpponentGfx
.type gHealthboxDoublesOpponentGfx, %object
.equ gHealthboxDoublesOpponentGfx, 146929656
.size gHealthboxDoublesOpponentGfx, 401
.global gHealthboxDoublesPlayerGfx
.type gHealthboxDoublesPlayerGfx, %object
.equ gHealthboxDoublesPlayerGfx, 146929248
.size gHealthboxDoublesPlayerGfx, 405
.global gHealthboxElementsGfxTable
.type gHealthboxElementsGfxTable, %object
.equ gHealthboxElementsGfxTable, 146873316
.size gHealthboxElementsGfxTable, 3776
.global gHealthboxSinglesOpponentGfx
.type gHealthboxSinglesOpponentGfx, %object
.equ gHealthboxSinglesOpponentGfx, 146928848
.size gHealthboxSinglesOpponentGfx, 398
.global gHealthboxSinglesPlayerGfx
.type gHealthboxSinglesPlayerGfx, %object
.equ gHealthboxSinglesPlayerGfx, 146928144
.size gHealthboxSinglesPlayerGfx, 701
.global gHoennTrainerCardFront_Tilemap
.type gHoennTrainerCardFront_Tilemap, %object
.equ gHoennTrainerCardFront_Tilemap, 139744144
.size gHoennTrainerCardFront_Tilemap, 414
.global gHoennTrainerCard_Gfx
.type gHoennTrainerCard_Gfx, %object
.equ gHoennTrainerCard_Gfx, 139740188
.size gHoennTrainerCard_Gfx, 1853
.global gIntroCopyright_Gfx
.type gIntroCopyright_Gfx, %object
.equ gIntroCopyright_Gfx, 140250260
.size gIntroCopyright_Gfx, 611
.global gKantoTrainerCardBack_Tilemap
.type gKantoTrainerCardBack_Tilemap, %object
.equ gKantoTrainerCardBack_Tilemap, 139745220
.size gKantoTrainerCardBack_Tilemap, 297
.global gKantoTrainerCard_Gfx
.type gKantoTrainerCard_Gfx, %object
.equ gKantoTrainerCard_Gfx, 139742044
.size gKantoTrainerCard_Gfx, 1726
.global gMenuInfoElements_Gfx
.type gMenuInfoElements_Gfx, %object
.equ gMenuInfoElements_Gfx, 140344376
.size gMenuInfoElements_Gfx, 8192
.global gMenuPokeblock_Gfx
.type gMenuPokeblock_Gfx, %object
.equ gMenuPokeblock_Gfx, 148485300
.size gMenuPokeblock_Gfx, 519
.global gMenuPokeblock_Tilemap
.type gMenuPokeblock_Tilemap, %object
.equ gMenuPokeblock_Tilemap, 148486676
.size gMenuPokeblock_Tilemap, 328
.global gMessageBox_Gfx
.type gMessageBox_Gfx, %object
.equ gMessageBox_Gfx, 139363808
.size gMessageBox_Gfx, 448
.global gMetatiles_Shop
.type gMetatiles_Shop, %object
.equ gMetatiles_Shop, 137920558
.size gMetatiles_Shop, 4624
.global gMonIcon_Jynx
.type gMonIcon_Jynx, %object
.equ gMonIcon_Jynx, 147349076
.size gMonIcon_Jynx, 1024
.global gMonMarkingsMenu_Gfx
.type gMonMarkingsMenu_Gfx, %object
.equ gMonMarkingsMenu_Gfx, 139960152
.size gMonMarkingsMenu_Gfx, 800
.global gMonPalette_Jynx
.type gMonPalette_Jynx, %object
.equ gMonPalette_Jynx, 147348236
.size gMonPalette_Jynx, 40
.global gMonShinyPalette_Jynx
.type gMonShinyPalette_Jynx, %object
.equ gMonShinyPalette_Jynx, 147349036
.size gMonShinyPalette_Jynx, 40
.global gMoveTypes_Gfx
.type gMoveTypes_Gfx, %object
.equ gMoveTypes_Gfx, 148468172
.size gMoveTypes_Gfx, 2693
.global gNamingScreenBackButton_Gfx
.type gNamingScreenBackButton_Gfx, %object
.equ gNamingScreenBackButton_Gfx, 139871896
.size gNamingScreenBackButton_Gfx, 480
.global gNamingScreenOKButton_Gfx
.type gNamingScreenOKButton_Gfx, %object
.equ gNamingScreenOKButton_Gfx, 139872408
.size gNamingScreenOKButton_Gfx, 480
.global gNamingScreenPageSwapFrame_Gfx
.type gNamingScreenPageSwapFrame_Gfx, %object
.equ gNamingScreenPageSwapFrame_Gfx, 139872920
.size gNamingScreenPageSwapFrame_Gfx, 640
.global gNamingScreenUnderscore_Gfx
.type gNamingScreenUnderscore_Gfx, %object
.equ gNamingScreenUnderscore_Gfx, 139872888
.size gNamingScreenUnderscore_Gfx, 32
.global gPartyMenuBg_Gfx
.type gPartyMenuBg_Gfx, %object
.equ gPartyMenuBg_Gfx, 148465568
.size gPartyMenuBg_Gfx, 709
.global gPokedexAreaScreenAreaUnknown_Gfx
.type gPokedexAreaScreenAreaUnknown_Gfx, %object
.equ gPokedexAreaScreenAreaUnknown_Gfx, 140065468
.size gPokedexAreaScreenAreaUnknown_Gfx, 450
.global gPokedexInterface_Gfx
.type gPokedexInterface_Gfx, %object
.equ gPokedexInterface_Gfx, 139692268
.size gPokedexInterface_Gfx, 1800
.global gPokedexSearchMenu_Gfx
.type gPokedexSearchMenu_Gfx, %object
.equ gPokedexSearchMenu_Gfx, 139737180
.size gPokedexSearchMenu_Gfx, 1417
.global gPokenavConditionCancel_Gfx
.type gPokenavConditionCancel_Gfx, %object
.equ gPokenavConditionCancel_Gfx, 140483640
.size gPokenavConditionCancel_Gfx, 256
.global gPokenavHeader_Gfx
.type gPokenavHeader_Gfx, %object
.equ gPokenavHeader_Gfx, 140442112
.size gPokenavHeader_Gfx, 556
.global gPokenavHeader_Tilemap
.type gPokenavHeader_Tilemap, %object
.equ gPokenavHeader_Tilemap, 140442668
.size gPokenavHeader_Tilemap, 379
.global gPokenavLeftHeaderBeauty_Gfx
.type gPokenavLeftHeaderBeauty_Gfx, %object
.equ gPokenavLeftHeaderBeauty_Gfx, 140447488
.size gPokenavLeftHeaderBeauty_Gfx, 307
.global gPokenavLeftHeaderCondition_Gfx
.type gPokenavLeftHeaderCondition_Gfx, %object
.equ gPokenavLeftHeaderCondition_Gfx, 140445500
.size gPokenavLeftHeaderCondition_Gfx, 371
.global gPokenavLeftHeaderCool_Gfx
.type gPokenavLeftHeaderCool_Gfx, %object
.equ gPokenavLeftHeaderCool_Gfx, 140447212
.size gPokenavLeftHeaderCool_Gfx, 276
.global gPokenavLeftHeaderCute_Gfx
.type gPokenavLeftHeaderCute_Gfx, %object
.equ gPokenavLeftHeaderCute_Gfx, 140447796
.size gPokenavLeftHeaderCute_Gfx, 310
.global gPokenavLeftHeaderHoennMap_Gfx
.type gPokenavLeftHeaderHoennMap_Gfx, %object
.equ gPokenavLeftHeaderHoennMap_Gfx, 140445872
.size gPokenavLeftHeaderHoennMap_Gfx, 625
.global gPokenavLeftHeaderMainMenu_Gfx
.type gPokenavLeftHeaderMainMenu_Gfx, %object
.equ gPokenavLeftHeaderMainMenu_Gfx, 140444348
.size gPokenavLeftHeaderMainMenu_Gfx, 363
.global gPokenavLeftHeaderMatchCall_Gfx
.type gPokenavLeftHeaderMatchCall_Gfx, %object
.equ gPokenavLeftHeaderMatchCall_Gfx, 140444712
.size gPokenavLeftHeaderMatchCall_Gfx, 366
.global gPokenavLeftHeaderParty_Gfx
.type gPokenavLeftHeaderParty_Gfx, %object
.equ gPokenavLeftHeaderParty_Gfx, 140446500
.size gPokenavLeftHeaderParty_Gfx, 359
.global gPokenavLeftHeaderRibbons_Gfx
.type gPokenavLeftHeaderRibbons_Gfx, %object
.equ gPokenavLeftHeaderRibbons_Gfx, 140445080
.size gPokenavLeftHeaderRibbons_Gfx, 418
.global gPokenavLeftHeaderSearch_Gfx
.type gPokenavLeftHeaderSearch_Gfx, %object
.equ gPokenavLeftHeaderSearch_Gfx, 140446860
.size gPokenavLeftHeaderSearch_Gfx, 349
.global gPokenavLeftHeaderSmart_Gfx
.type gPokenavLeftHeaderSmart_Gfx, %object
.equ gPokenavLeftHeaderSmart_Gfx, 140448108
.size gPokenavLeftHeaderSmart_Gfx, 283
.global gPokenavLeftHeaderTough_Gfx
.type gPokenavLeftHeaderTough_Gfx, %object
.equ gPokenavLeftHeaderTough_Gfx, 140448392
.size gPokenavLeftHeaderTough_Gfx, 318
.global gPokenavOptions_Gfx
.type gPokenavOptions_Gfx, %object
.equ gPokenavOptions_Gfx, 140450960
.size gPokenavOptions_Gfx, 2522
.global gPokenavOptions_Tilemap
.type gPokenavOptions_Tilemap, %object
.equ gPokenavOptions_Tilemap, 140466428
.size gPokenavOptions_Tilemap, 72
.global gRegionMapCityZoomText_Gfx
.type gRegionMapCityZoomText_Gfx, %object
.equ gRegionMapCityZoomText_Gfx, 140462744
.size gRegionMapCityZoomText_Gfx, 609
.global gRouletteCredit_Gfx
.type gRouletteCredit_Gfx, %object
.equ gRouletteCredit_Gfx, 148629252
.size gRouletteCredit_Gfx, 335
.global gShopMenuMoney_Gfx
.type gShopMenuMoney_Gfx, %object
.equ gShopMenuMoney_Gfx, 148485160
.size gShopMenuMoney_Gfx, 140
.global gShopMenu_Gfx
.type gShopMenu_Gfx, %object
.equ gShopMenu_Gfx, 148484532
.size gShopMenu_Gfx, 265
.global gSlotMachineDigitalDisplay_Gfx
.type gSlotMachineDigitalDisplay_Gfx, %object
.equ gSlotMachineDigitalDisplay_Gfx, 140007056
.size gSlotMachineDigitalDisplay_Gfx, 1894
.global gSlotMachinePikaPowerBolt
.type gSlotMachinePikaPowerBolt, %object
.equ gSlotMachinePikaPowerBolt, 139998088
.size gSlotMachinePikaPowerBolt, 32
.global gSlotMachineReelSymbol6Tiles
.type gSlotMachineReelSymbol6Tiles, %object
.equ gSlotMachineReelSymbol6Tiles, 139996424
.size gSlotMachineReelSymbol6Tiles, 512
.global gSlotMachineReelSymbol7Tiles
.type gSlotMachineReelSymbol7Tiles, %object
.equ gSlotMachineReelSymbol7Tiles, 139996936
.size gSlotMachineReelSymbol7Tiles, 512
.global gStatusGfx_Icons
.type gStatusGfx_Icons, %object
.equ gStatusGfx_Icons, 148467524
.size gStatusGfx_Icons, 608
.global gStorageSystemMenu_Gfx
.type gStorageSystemMenu_Gfx, %object
.equ gStorageSystemMenu_Gfx, 139771804
.size gStorageSystemMenu_Gfx, 1728
.global gStorageSystemPartyMenu_Tilemap
.type gStorageSystemPartyMenu_Tilemap, %object
.equ gStorageSystemPartyMenu_Tilemap, 139773532
.size gStorageSystemPartyMenu_Tilemap, 175
.global gTilesetTiles_BattleDome
.type gTilesetTiles_BattleDome, %object
.equ gTilesetTiles_BattleDome, 137747296
.size gTilesetTiles_BattleDome, 4685
.global gTilesetTiles_General
.type gTilesetTiles_General, %object
.equ gTilesetTiles_General, 137428308
.size gTilesetTiles_General, 8913
.global gTilesetTiles_Shop
.type gTilesetTiles_Shop, %object
.equ gTilesetTiles_Shop, 137531100
.size gTilesetTiles_Shop, 5664
.global gTitleScreenBgPalettes
.type gTitleScreenBgPalettes, %object
.equ gTitleScreenBgPalettes, 139557720
.size gTitleScreenBgPalettes, 192
.global gTitleScreenCloudsTilemap
.type gTitleScreenCloudsTilemap, %object
.equ gTitleScreenCloudsTilemap, 139569612
.size gTitleScreenCloudsTilemap, 576
.global gTitleScreenEmeraldVersionGfx
.type gTitleScreenEmeraldVersionGfx, %object
.equ gTitleScreenEmeraldVersionGfx, 139563916
.size gTitleScreenEmeraldVersionGfx, 1608
.global gTitleScreenEmeraldVersionPal
.type gTitleScreenEmeraldVersionPal, %object
.equ gTitleScreenEmeraldVersionPal, 139557720
.size gTitleScreenEmeraldVersionPal, 288
.global gTitleScreenPokemonLogoGfx
.type gTitleScreenPokemonLogoGfx, %object
.equ gTitleScreenPokemonLogoGfx, 139557912
.size gTitleScreenPokemonLogoGfx, 6002
.global gTitleScreenPokemonLogoTilemap
.type gTitleScreenPokemonLogoTilemap, %object
.equ gTitleScreenPokemonLogoTilemap, 139557536
.size gTitleScreenPokemonLogoTilemap, 184
.global gTitleScreenPressStartGfx
.type gTitleScreenPressStartGfx, %object
.equ gTitleScreenPressStartGfx, 139556596
.size gTitleScreenPressStartGfx, 659
.global gTradeCursor_Gfx
.type gTradeCursor_Gfx, %object
.equ gTradeCursor_Gfx, 137363436
.size gTradeCursor_Gfx, 2048
.global gTradeGba_Gfx
.type gTradeGba_Gfx, %object
.equ gTradeGba_Gfx, 137387396
.size gTradeGba_Gfx, 5120
.global gTradeMenu_Gfx
.type gTradeMenu_Gfx, %object
.equ gTradeMenu_Gfx, 137351500
.size gTradeMenu_Gfx, 4736
.global gTradeMenu_Tilemap
.type gTradeMenu_Tilemap, %object
.equ gTradeMenu_Tilemap, 137356236
.size gTradeMenu_Tilemap, 2048
.global gUnused_PokedexNoBall
.type gUnused_PokedexNoBall, %object
.equ gUnused_PokedexNoBall, 139689540
.size gUnused_PokedexNoBall, 71
.global gUsePokeblockCondition_Gfx
.type gUsePokeblockCondition_Gfx, %object
.equ gUsePokeblockCondition_Gfx, 140241856
.size gUsePokeblockCondition_Gfx, 371
.global gUsePokeblockUpDown_Gfx
.type gUsePokeblockUpDown_Gfx, %object
.equ gUsePokeblockUpDown_Gfx, 140241344
.size gUsePokeblockUpDown_Gfx, 512
.global gWallpaperTiles_Horizontal
.type gWallpaperTiles_Horizontal, %object
.equ gWallpaperTiles_Horizontal, 139796764
.size gWallpaperTiles_Horizontal, 604
.global gWallpaperTiles_Ribbon
.type gWallpaperTiles_Ribbon, %object
.equ gWallpaperTiles_Ribbon, 139799272
.size gWallpaperTiles_Ribbon, 613
.global s321Start_Gfx
.type s321Start_Gfx, %object
.equ s321Start_Gfx, 137175044
.size s321Start_Gfx, 1105
.global sBonuses_Gfx
.type sBonuses_Gfx, %object
.equ sBonuses_Gfx, 137169428
.size sBonuses_Gfx, 2735
.global sBonuses_Tilemap
.type sBonuses_Tilemap, %object
.equ sBonuses_Tilemap, 137172164
.size sBonuses_Tilemap, 1322
.global sConditionSearchResultTiles
.type sConditionSearchResultTiles, %object
.equ sConditionSearchResultTiles, 140466672
.size sConditionSearchResultTiles, 198
.global sCreditsCopyrightEnd_Gfx
.type sCreditsCopyrightEnd_Gfx, %object
.equ sCreditsCopyrightEnd_Gfx, 140273708
.size sCreditsCopyrightEnd_Gfx, 1084
.global sCryMeter_Gfx
.type sCryMeter_Gfx, %object
.equ sCryMeter_Gfx, 140083180
.size sCryMeter_Gfx, 821
.global sFont_Braille
.type sFont_Braille, %object
.equ sFont_Braille, 140384736
.size sFont_Braille, 4096
.global sMapScreen_Gfx
.type sMapScreen_Gfx, %object
.equ sMapScreen_Gfx, 139755880
.size sMapScreen_Gfx, 4073
.global sMatchCallUI_Gfx
.type sMatchCallUI_Gfx, %object
.equ sMatchCallUI_Gfx, 140459728
.size sMatchCallUI_Gfx, 164
.global sMonRibbonListFrameTiles
.type sMonRibbonListFrameTiles, %object
.equ sMonRibbonListFrameTiles, 140467188
.size sMonRibbonListFrameTiles, 198
